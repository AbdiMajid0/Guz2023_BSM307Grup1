from web3 import Web3

w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:8551"))

transaction_hash = "0xD207E1c99364dF062f3DAEf4E085B46bC6c86046"

transaction_receipt = w3.eth.get_transaction_receipt(transaction_hash)

if transaction_receipt is not None:
    print("Transaction confirmed")
else:
    print("Transaction not confirmed")