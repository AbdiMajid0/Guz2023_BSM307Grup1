from web3.auto.gethdev import w3
w3.is_connected()





# import web3
# from web3 import Web3
#
# my_provider = web3.IPCProvider('\\.\pipe\geth.ipc')
#
# # my_provider = Web3.IPCProvider('\\.\pipe\geth.ipc')
# # print(my_provider)
